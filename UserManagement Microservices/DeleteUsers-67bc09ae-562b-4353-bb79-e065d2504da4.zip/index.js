const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
  try {
    const username = event.pathParameters.username;
    // Delete the user from AWS Cognito
    const cognitoParams = {
      UserPoolId: 'us-east-1_7mJKXyGpw', 
      Username: username, 
    };
    await cognito.adminDeleteUser(cognitoParams).promise();

    // Delete the user from DynamoDB
    const dynamoDBParams = {
      TableName: 'users',
      Key: { username }, 
    };
    await dynamodb.delete(dynamoDBParams).promise();

    console.log('User deleted successfully from both AWS Cognito and DynamoDB.');

    return {
      statusCode: 200,
      body: 'Success',
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: 'Error',
    };
  }
};
