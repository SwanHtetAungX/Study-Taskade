const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
exports.handler = (event, context, callback) => {
let body;
let response;

switch (event.routeKey) {


case 'PUT /users/{username}':
body = JSON.parse(event.body);
var params = {
TableName : 'users',
Key: {"username" : event.pathParameters.username},
UpdateExpression: "set ContactNo = :ContactNo, FirstName = :FirstName, LastName = :LastName, Occupation = :Occupation, Organization = :Organization, ProfileImgUrl =:ProfileImgUrl",
ExpressionAttributeValues: {
":ContactNo": body.ContactNo,
":FirstName": body.FirstName,
":LastName": body.LastName,
":Occupation":body.Occupation,
":Organization":body.Organization,

":ProfileImgUrl":body.ProfileImgUrl
},
}
dynamo.update(params, function (err, result) {
if (err) throw err;
return callback(null, {"message": "user edited"});
});
break;


case 'GET /user-information/{username}':
      var params = {
      TableName : 'users',
      KeyConditionExpression: 'username = :username',
      ExpressionAttributeValues: {
        ':username': event.pathParameters.username,
        },
      };
      
      dynamo.query(params, function (err, result) {
      	if (err) throw err;
      	return callback(null, result);
    	});
    	break;
default:
throw new Error("Unsupported route: " + event.routeKey);
}
}