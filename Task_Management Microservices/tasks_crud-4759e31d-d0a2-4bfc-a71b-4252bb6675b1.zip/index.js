const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
  let body;
  let response;
  let username;
  let task_id;
  let timeStamp;

  switch (event.routeKey) {
    case 'POST /tasks':
  body = JSON.parse(event.body);
  username = body.username;
  timeStamp = new Date().toISOString();
  task_id = `${timeStamp}_${username}`;
  var params = {
    TableName: 'task_management',
    FilterExpression: 'task_id = :task_id AND username = :username',
    ExpressionAttributeValues: {
      ':task_id': task_id,
      ':username': username,
    },
  };

  dynamo.scan(params, function (err, result) {
    if (err) throw err;

    if (result.Count > 0) {
      return callback(null, { "message": "duplicated task" });
    }

    body.created_at = new Date().toISOString();
    body.updated_at = body.created_at;
    body.task_id=task_id;

    var params = {
      TableName: 'task_management',
      Item: body
    };

    dynamo.put(params, function (err, result) {
      if (err) throw err;
      return callback(null, { "message": "task added successfully" });
    });
  });
  break;

    case 'PUT /tasks/{task_id}':
  body = JSON.parse(event.body);
  const username = body.username; 

  var params = {
    TableName: 'task_management',
    Key: {
      "task_id": event.pathParameters.task_id
    },
    UpdateExpression: "set details = :details, due_date = :due_date, priority = :priority, resources = :resources, title = :title, updated_at = :updated_at",
    ConditionExpression: "username = :username", // Add the condition expression
    ExpressionAttributeValues: {
      ":details": body.details,
      ":due_date": body.due_date,
      ":priority": body.priority,
      ":resources": body.resources,
      ":title": body.title,
      ":updated_at": new Date().toISOString(),
      ":username": username 
    },
  };

  dynamo.update(params, function (err, result) {
    if (err) {
      if (err.code === 'ConditionalCheckFailedException') {
        return callback(null, { "message": "You are not authorized to edit this task." });
      }
      throw err;
    }
    return callback(null, { "message": "Task edited successfully" });
  });
  break;

    case 'DELETE /tasks/{task_id}/{username}':
    
      var params = {
        TableName : 'task_management',
        Key: {"task_id" : event.pathParameters.task_id}}
      
      dynamo.delete(params, function (err, result) {
      	if (err) throw err;
      	return callback(null, {"message": "task is  deleted successfully"});
    	});
    	break;
    case 'GET /tasks/{username}':
      var params = {
      TableName : 'task_management',
      FilterExpression: "username = :username",
      ExpressionAttributeValues: {
        ':username': event.pathParameters.username,
        },
      };
      
      dynamo.scan(params, function (err, result) {
      	if (err) throw err;
      	return callback(null, result);
    	});
    	break;
    	case 'GET /sorted-tasks/{username}':
      username = event.pathParameters.username;
      const queryParams = event.queryStringParameters;

      // Set the default sorting options
      let sortAttribute = "due_date";
      let sortOrder = "ASC";

      // Check if sorting options are provided in the query parameters
      if (queryParams && queryParams.sortAttribute) {
        sortAttribute = queryParams.sortAttribute;
      }
      if (queryParams && queryParams.sortOrder) {
        sortOrder = queryParams.sortOrder;
      }

        params = {
        TableName: 'task_management',
        FilterExpression: "username = :username",
        ExpressionAttributeValues: {
          ':username': username,
        },
        ScanIndexForward: sortOrder.toUpperCase() === "ASC",
      };

      dynamo.scan(params, function (err, result) {
        if (err) {
          console.error("Error scanning tasks:", err);
          return callback(null, { "message": "An error occurred while retrieving tasks." });
        }

        // Check if there are no tasks found
        if (result.Items.length === 0) {
          return callback(null, { "message": "No tasks found." });
        }

        // Sorting the tasks based on the selected attribute
        const tasks = result.Items;
        tasks.sort((a, b) => {
          if (sortAttribute === "due_date") {
            const dateA = new Date(a.due_date);
            const dateB = new Date(b.due_date);
            return dateA - dateB;
          } else if (sortAttribute === "priority") {
            const priorityOrder = { "High": 1, "Medium": 2, "Low": 3 };
            return priorityOrder[a.priority] - priorityOrder[b.priority];
          } else {
            // Sort by created_at by default
            const dateA = new Date(a.created_at);
            const dateB = new Date(b.created_at);
            return dateA - dateB;
          }
        });

        return callback(null, tasks);
      });
      break;
    default: 
      throw new Error("Unsupported route: " + event.routeKey);
  }
}

