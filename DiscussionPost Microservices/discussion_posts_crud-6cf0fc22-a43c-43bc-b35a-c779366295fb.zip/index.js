const mysql = require('mysql');

const con = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME
});

exports.handler = (event, context, callback) => {
  let sql;
  context.callbackWaitsForEmptyEventLoop = false;
  switch (event.routeKey) {
    case 'GET /discussion-posts':
      sql = "SELECT * FROM `discussion_posts`.`discussion_post`;";
      con.query(sql, function (err, result) {
        if (err) {
          console.error("Error retrieving discussion posts:", err);
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error retrieving discussion posts" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
    
    case 'GET /discussion-posts/{username}':
      sql = "SELECT * FROM `discussion_posts`.`discussion_post` WHERE username = ?;";
      con.query(sql, [event.pathParameters.username], function (err, result) {
        if (err) {
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error retrieving discussion posts" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'GET /discussion-posts/comments/{post_id}':
      sql = "SELECT * FROM `discussion_posts`.`comment` WHERE post_id = ?;";
      con.query(sql, [event.pathParameters.post_id], function (err, result) {
        if (err) {
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error retrieving comments for post" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'POST /add-posts':
      const body = JSON.parse(event.body);
      sql = "INSERT INTO `discussion_posts`.`discussion_post` (`username`, `title`, `content`, `img_url`, `created_at`) VALUES (?, ?, ?, ?, ?);";
      con.query(sql, [body.username, body.title, body.content, body.img_url, new Date().toISOString().slice(0, 10)], function (err, result) {
        if (err) {
          
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error adding discussion post" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'POST /comments':
      const commentBody = JSON.parse(event.body);
      sql = "INSERT INTO `discussion_posts`.`comment` (`post_id`, `username`, `content`, `attachment_url`, `created_at`) VALUES (?, ?, ?, ?, ?);";
      con.query(sql, [commentBody.post_id, commentBody.username, commentBody.content, commentBody.attachment_url, new Date().toISOString().slice(0, 10)], function (err, result) {
        if (err) {
                    return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error adding comment" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'PUT /posts/{post_id}':
      const postUpdateBody = JSON.parse(event.body);
      sql = "UPDATE `discussion_posts`.`discussion_post` SET `title` = ?, `content` = ?, `img_url` = ? WHERE post_id = ?;";
      con.query(sql, [postUpdateBody.title, postUpdateBody.content, postUpdateBody.img_url, event.pathParameters.post_id], function (err, result) {
        if (err) {
    
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error updating discussion post" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'PUT /comments/{comment_id}':
      const commentUpdateBody = JSON.parse(event.body);
      sql = "UPDATE `discussion_posts`.`comment` SET `content` = ?, `attachment_url` = ? WHERE comment_id = ?;";
      con.query(sql, [commentUpdateBody.content, commentUpdateBody.attachment_url, event.pathParameters.comment_id], function (err, result) {
        if (err) {
         
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error updating comment" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'DELETE /posts/{post_id}':
      sql = "DELETE FROM `discussion_posts`.`discussion_post` WHERE post_id = ?;";
      con.query(sql, [event.pathParameters.post_id], function (err, result) {
        if (err) {
         
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error deleting discussion post" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'DELETE /comments/{comment_id}':
      sql = "DELETE FROM `discussion_posts`.`comment` WHERE comment_id = ?;";
      con.query(sql, [event.pathParameters.comment_id], function (err, result) {
        if (err) {
          
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error deleting comment" })
          });
        }
        return callback(null, {
          statusCode: 200,
          result
        });
      });
      break;
      
    case 'GET /discussion-posts/search':
      const keyword = event.queryStringParameters.keyword;
      sql = "SELECT * FROM `discussion_posts`.`discussion_post` WHERE LOWER(title) LIKE ? OR LOWER(content) LIKE ?;";
      con.query(sql, [`%${keyword.toLowerCase()}%`, `%${keyword.toLowerCase()}%`], function (err, result) {
        if (err) {
          return callback(null, {
            statusCode: 500,
            body: JSON.stringify({ error: "Error searching discussion posts" })
          });
        }
        return callback(null, {
          statusCode:          200,
          result
        });
      });
      break;
      
    default:
      return callback(null, {
        statusCode: 400,
        body: JSON.stringify({ error: "Unsupported route" })
      });
  }
};


