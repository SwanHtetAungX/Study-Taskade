const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
  let body;
  let response;
  let task_id;
  let timeStamp;
  let username;

  switch (event.routeKey) {
    case 'POST /pomodoro-tasks':
      body = JSON.parse(event.body);
      username = body.username;
      timeStamp = new Date().toISOString();
      task_id = `${timeStamp}_${username}`;

      var params = {
        TableName: 'task_list_for_pomodoro_timer',
        FilterExpression: 'task_id = :task_id AND username = :username',
        ExpressionAttributeValues: {
          ':task_id': task_id,
          ':username': username,
        },
      };

      dynamo.scan(params, function (err, result) {
        if (err) throw err;

        if (result.Count > 0) {
          return callback(null, { "message": "duplicated task" });
        }

        body.created_at = new Date().toISOString();
        body.is_complete = false;
        body.task_id = task_id;
 

        var params = {
          TableName: 'task_list_for_pomodoro_timer',
          Item: body
        };

        dynamo.put(params, function (err, result) {
          if (err) throw err;
          return callback(null, { "message": "task added successfully" });
        });
      });
      break;

    case 'PUT /tasks/{task_id}':
      body = JSON.parse(event.body);

      var params = {
        TableName: 'task_list_for_pomodoro_timer',
        Key: {
          "task_id": event.pathParameters.task_id,
          "username": event.pathParameters.username
        },
        UpdateExpression: "SET is_complete = :is_complete, task_position = :task_position, task_name = :task_name, time_estimate = :time_estimate",
        ExpressionAttributeValues: {
          ":is_complete": body.is_complete,
          ":task_position": body.task_position,
          ":task_name": body.task_name,
          ":time_estimate": body.time_estimate,
        },
      };

      dynamo.update(params, function (err, result) {
        if (err) { throw err; }
        return callback(null, { "message": "Task edited successfully" });
      });
      break;

    case 'DELETE /tasks/{task_id}/{username}':
      var params = {
        TableName: 'task_list_for_pomodoro_timer',
        Key: {
          "task_id": event.pathParameters.task_id,
          "username": event.pathParameters.username
        }
      };

      dynamo.delete(params, function (err, result) {
        if (err) throw err;
        return callback(null, { "message": "Task is deleted successfully" });
      });
      break;

    case 'GET /tasks/{username}':
      var params = {
        TableName: 'task_list_for_pomodoro_timer',
        FilterExpression: "username = :username",
        ExpressionAttributeValues: {
          ':username': event.pathParameters.username,
        },
      };

      dynamo.scan(params, function (err, result) {
        if (err) throw err;

        // Calculate the total time estimate
        let totalEstimate = 0;
        result.Items.forEach((task) => {
          if (task.time_estimate) {
            totalEstimate += parseInt(task.time_estimate);
          }
        });

        const response = {
          tasks: result.Items,
          total_estimate: totalEstimate,
        };

        return callback(null, response);
      });
      break;

    case 'PUT /tasks/reorder':
      const reorderBody=JSON.parse(event.body)
      const { username, task_id_list } = reorderBody;

      // Update the task positions
      const updatePromises = task_id_list.map((task_id, index) => {
        const params = {
          TableName: 'task_list_for_pomodoro_timer',
          Key: {
            "task_id": task_id,
            "username": username
          },
          UpdateExpression: "SET task_position = :task_position",
          ExpressionAttributeValues: {
            ":task_position": index + 1
          }
        };

        return dynamo.update(params).promise();
      });

      Promise.all(updatePromises)
        .then(() => {
          return callback(null, { "message": "Tasks reordered successfully" });
        })
        .catch((err) => {
          throw err;
        });
      break;

    default:
      throw new Error("Unsupported route: " + event.routeKey);
  }
};
